# SafeChat: Hate Speech & Offensive Language Detection

This repository contains the implementation of my dissertation project, where I built and evaluated machine learning models (SVM, LSTM, BERT) for hate speech and offensive content detection on Twitter data. Additionally, I created a Streamlit application (`app.py`) with a WhatsApp-style chat interface to demonstrate real-time filtering of harmful messages.

## Project Overview
- **Objective**: Detect and filter hate speech, offensive, and neutral tweets using machine learning and natural language processing techniques.  
- **Dataset**: Twitter dataset labeled as Hate Speech, Offensive, Neutral.  
- **Models Implemented**:
  - Support Vector Machine (SVM) with TF-IDF and Data Augmentation  
  - Long Short-Term Memory (LSTM)  
  - BERT (Transformer-based model)  

- **Streamlit Application**:  
  - Provides a WhatsApp-like chat interface.  
  - Neutral messages are allowed and marked as sent.  
  - Hate/Offensive messages are blocked with an error message explaining the reason.


## Installation
Clone the repository:
```bash
git clone repo from github link
cd safechat-hatespeech
```

Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate   # On Mac/Linux
venv\Scripts\activate      # On Windows
```

Install dependencies:
```bash
pip install -r requirements.txt
```

## Requirements
The key dependencies include:
- streamlit  
- scikit-learn  
- pandas  
- numpy  
- seaborn  
- matplotlib  
- nltk  
- joblib  
- wordcloud  
- torch and transformers (for BERT, optional)

## Usage
To run the Streamlit application:
```bash
python -m streamlit run app.py
```
The application will start locally on `http://localhost:8501`.

## Results

### SVM Classification Report
| Class        | Precision | Recall | F1-Score |
|--------------|-----------|--------|----------|
| Hate Speech  | 0.74      | 0.29   | 0.42     |
| Offensive    | 0.94      | 0.97   | 0.95     |
| Neutral      | 0.87      | 0.92   | 0.90     |

Accuracy: 92%

### LSTM Model Performance
- Final Validation Accuracy: 96.16%  
- Some overfitting observed after epoch 5.  

### BERT Model Performance
- Final Validation Accuracy: 99.03%  
- Best performing model among those tested.  

## Appendix
- Preprocessing scripts (cleaning, tokenization, augmentation).  
- Training notebooks for SVM, LSTM, and BERT.  
- Results including classification reports, confusion matrices, and training logs.  

## Author
Engr. Bilal Ahmad  
MSc Dissertation Project (2025)  

## License
This project is licensed under the MIT License.
