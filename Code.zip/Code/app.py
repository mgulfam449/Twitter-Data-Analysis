import streamlit as st
import joblib
import re
import string
import pandas as pd

# -----------------------------
# Load Model & Vectorizer
# -----------------------------
svm_model = joblib.load("svm_model.joblib")
vectorizer = joblib.load("vectorizer.joblib")

# -----------------------------
# Helper function to clean text
# -----------------------------
def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+|www\S+|https\S+", '', text)  # Remove URLs
    text = re.sub(r"@\w+", '', text)  # Remove mentions
    text = re.sub(r"#\w+", '', text)  # Remove hashtags
    text = re.sub(r"\d+", '', text)   # Remove numbers
    text = text.translate(str.maketrans('', '', string.punctuation))  # Remove punctuation
    return text.strip()

# -----------------------------
# Refit vectorizer on dataset
# -----------------------------
try:
    df = pd.read_csv("Twitter Dataset.csv")
    df['clean_text'] = df['tweet'].apply(clean_text)
    vectorizer.fit(df['clean_text'])  # Refit so it has vocabulary
except Exception as e:
    st.error(f"❌ Dataset not found or invalid: {e}")

# -----------------------------
# Label mapping
# -----------------------------
label_map = {0: "Hate Speech", 1: "Offensive", 2: "Neutral"}

# -----------------------------
# Streamlit UI
# -----------------------------
st.set_page_config(page_title="SafeChat - WhatsApp Style", page_icon="💬", layout="centered")

st.markdown("<h2 style='text-align:center;'>💬 SafeChat (WhatsApp Style)</h2>", unsafe_allow_html=True)
st.write("Messages classified as **Neutral ✅** will be sent, while Hate/Offensive ones will be blocked ❌.")

# Chat history (session state)
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []  # [(msg, label, status)]

# -----------------------------
# User input
# -----------------------------
with st.form("chat_form", clear_on_submit=True):
    user_input = st.text_input("Type your message...")
    submitted = st.form_submit_button("Send")

if submitted and user_input.strip() != "":
    cleaned = clean_text(user_input)
    vec = vectorizer.transform([cleaned])
    prediction = svm_model.predict(vec)[0]
    label = label_map[prediction]

    if label == "Neutral":
        st.session_state.chat_history.append((user_input, label, "✅ Sent"))
    else:
        st.session_state.chat_history.append(
            (
                user_input,
                label,
                f"❌ Failed to Send\nReason: {label}\n⚠️ Warning: Your activity may be reported."
            )
        )

# -----------------------------
# Display Chat History (WhatsApp style)
# -----------------------------
st.markdown("---")
st.subheader("Chat")

for msg, label, status in st.session_state.chat_history:
    if "Sent" in status:
        st.markdown(
            f"""
            <div style="background-color:#dcf8c6; padding:10px; border-radius:10px; margin:5px 0; max-width:70%; float:right; clear:both;">
                <p style="margin:0;">{msg}</p>
                <p style="font-size:12px; color:gray; text-align:right; margin:0;">{status}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            f"""
            <div style="background-color:#f8d7da; padding:10px; border-radius:10px; margin:5px 0; max-width:70%; float:left; clear:both;">
                <p style="margin:0;">{msg}</p>
                <p style="font-size:12px; color:red; margin:0;">{status}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
